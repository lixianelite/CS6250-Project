package Login_Sys;
//import Login_Sys2.Login_system2;   // import the package
import ChatServer.J_ChatServer;

//import javax.swing.*;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JScrollPane;

import java.util.*;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

//import java.awt.*;


public class Login_system {
	private Map<String, String> map;
	private JFrame frame;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_system window = new Login_system();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_system() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		map = new HashMap<>();
		map.put("xzhu", "12345");
		map.put("one", "king");

		frame = new JFrame();
		frame.setBounds(200, 200, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblLogin = new JLabel("Please Log In ");
		lblLogin.setBounds(166, 39, 105, 16);
		frame.getContentPane().add(lblLogin);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(70, 93, 73, 16);
		frame.getContentPane().add(lblUsername);

		JLabel lblPssword = new JLabel("Password");
		lblPssword.setBounds(70, 142, 73, 16);
		frame.getContentPane().add(lblPssword);

		txtUsername = new JTextField();
		txtUsername.setBounds(143, 88, 119, 26);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);

		txtPassword = new JPasswordField();
		txtPassword.setBounds(143, 137, 120, 26);
		frame.getContentPane().add(txtPassword);

		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// check the provided login information
				String password = String.valueOf(txtPassword.getPassword()); //txtPassword.getText();
				String username = txtUsername.getText();
				//if (password.contains("king") && username.contains("one")) {
				if (map.containsKey(username) && map.get(username).equals(password)) {
					txtPassword.setText(null);
					txtUsername.setText(null);
					// jump to next info & need to import this package

					//Login_system2 newWindow = new Login_system2();
					//newWindow.main(null);

					frame.setVisible(false); // make current frame disappear
					J_ChatServer app = new J_ChatServer();
					app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					app.setSize(500,400); // change the frame size
					app.setVisible(true);

				} else {
					JOptionPane.showMessageDialog(null, "Please provide valid login information","Login Error", JOptionPane.ERROR_MESSAGE);
					txtPassword.setText(null);
					txtUsername.setText(null);
				}
			}
		});
		btnLogin.setBounds(226, 224, 117, 29);
		frame.getContentPane().add(btnLogin);

		/*
		// Reset the username and password textbox:
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				txtUsername.setText(null);
				txtPassword.setText(null);
			}
		});
		btnReset.setBounds(44, 224, 117, 29);
		frame.getContentPane().add(btnReset);
		*/
	}
}
